(function(){
  var y = document.getElementById('y'); if (y) y.textContent = new Date().getFullYear();
})();
