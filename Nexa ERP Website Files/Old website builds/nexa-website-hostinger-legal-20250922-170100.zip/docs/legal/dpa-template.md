# DPA — Template
Roles, purpose, sub-processors, safeguards.
