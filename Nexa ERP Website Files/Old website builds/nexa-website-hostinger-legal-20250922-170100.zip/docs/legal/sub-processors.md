# Sub-processors
Hosting, analytics (consent only), payments, banking.
