# Runbook — VAT (UK MTD)
Authorise → Obligations → Submit → Payments
