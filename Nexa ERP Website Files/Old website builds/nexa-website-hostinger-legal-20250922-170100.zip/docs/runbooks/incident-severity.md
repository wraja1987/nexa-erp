# Incident Severity
Sev1 (major) → Sev4 (minor). Roles, SLAs, communications.
