# Runbook — Procure to Pay
1) Requisition → 2) PO → 3) Receipt → 4) Invoice → 5) Payment
