# Runbook — Project Billing
Milestones or T&M → Approvals → Invoice → Revenue
