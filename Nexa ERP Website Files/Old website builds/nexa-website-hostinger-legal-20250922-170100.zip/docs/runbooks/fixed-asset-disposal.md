# Runbook — Fixed Asset Disposal
Identify → Revalue (if needed) → Dispose → Journal
