# Runbook — Make to Stock
Plan → Produce → Store → Dispatch
