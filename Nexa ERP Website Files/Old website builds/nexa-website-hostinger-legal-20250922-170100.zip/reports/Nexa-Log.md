[20250922-165651] Stage G applied to website package (no deletions, originals preserved):
- Added Privacy/Terms/Cookies in theme (laptop + mobile header/footer reused).
- Inserted compact Legal link in header; Privacy/Terms/Cookies in footer.
- Enabled consent banner across pages.
- Wrote Stage G docs (simple British English, no images).
- Saved scan report: stage-G-scan-20250922-165651.txt
