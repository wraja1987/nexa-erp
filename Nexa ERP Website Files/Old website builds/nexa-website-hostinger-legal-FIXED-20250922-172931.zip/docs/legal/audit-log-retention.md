# Audit Log Retention
Keep logs short; rotate and delete on schedule.
