# Runbook — Key Rotation
Prepare new keys → Update env → Restart → Verify.
