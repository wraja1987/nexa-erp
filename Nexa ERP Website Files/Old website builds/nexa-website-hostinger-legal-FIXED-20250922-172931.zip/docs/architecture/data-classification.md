# Data Classification
- Customer data: Confidential; keep only as needed.
- Audit logs: Internal; rotate and delete per policy.
