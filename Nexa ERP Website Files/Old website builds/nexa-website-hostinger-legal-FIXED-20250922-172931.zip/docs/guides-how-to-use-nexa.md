# How to use Nexa
1) Sign in to the portal.
2) Choose a module (for example Finance).
3) Check KPIs and use Quick Links for common actions.
4) Use the AI bar for help in plain English.
5) Save or export reports.
