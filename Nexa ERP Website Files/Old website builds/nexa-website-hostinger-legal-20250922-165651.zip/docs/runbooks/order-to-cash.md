# Runbook — Order to Cash
1) Quote → 2) Order → 3) Fulfil → 4) Invoice → 5) Cash
