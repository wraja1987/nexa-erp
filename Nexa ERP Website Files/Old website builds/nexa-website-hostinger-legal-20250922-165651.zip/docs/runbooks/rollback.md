# Runbook — Rollback
Restore last good build → Verify → Communicate recovery.
