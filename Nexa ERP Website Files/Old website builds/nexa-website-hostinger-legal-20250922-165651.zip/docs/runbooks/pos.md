# Runbook — POS
Sale → Payment → Receipt → Day end
