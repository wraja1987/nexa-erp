# GDPR — Overview
Lawful basis, data rights, retention, DPIA prompts.
