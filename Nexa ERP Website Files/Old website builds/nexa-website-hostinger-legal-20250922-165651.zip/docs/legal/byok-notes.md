# BYOK Notes
Generate, rotate, verify master key safely.
