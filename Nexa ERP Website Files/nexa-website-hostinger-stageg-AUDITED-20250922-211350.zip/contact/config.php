<?php
define('USE_SMTP', true);
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_SECURE', 'tls');
define('SMTP_USERNAME', 'nexaaierp@gmail.com');
define('SMTP_PASSWORD', 'qbln nfjh olyo tmbf');
define('MAIL_TO', 'info@chiefaa.com');
define('MAIL_FROM_EMAIL', 'nexaaierp@gmail.com');
define('MAIL_FROM_NAME', 'Nexa Website');
?>
