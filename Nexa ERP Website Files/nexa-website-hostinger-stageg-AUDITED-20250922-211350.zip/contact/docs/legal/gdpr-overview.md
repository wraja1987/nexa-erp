# GDPR Overview (Plain English)
We collect only what we need, keep it secure, and delete it when no longer required.
