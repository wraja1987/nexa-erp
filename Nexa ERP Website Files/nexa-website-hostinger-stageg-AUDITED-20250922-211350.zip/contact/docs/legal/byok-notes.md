# BYOK Notes
Generate and rotate keys; store in a secure vault.
