# Data Processing Addendum (Template)
Template; review with legal counsel.
