# vat uk mtd — Runbook

## Goal
Clear steps to complete the vat uk mtd process.

## Steps
1) Start
2) Enter details
3) Review
4) Approve
5) Complete
