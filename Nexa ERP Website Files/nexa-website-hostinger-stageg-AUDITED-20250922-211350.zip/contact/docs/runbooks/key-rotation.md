# key rotation — Runbook

## Purpose
Simple, reliable steps to perform key rotation.

## Steps
- Follow the checklist.
