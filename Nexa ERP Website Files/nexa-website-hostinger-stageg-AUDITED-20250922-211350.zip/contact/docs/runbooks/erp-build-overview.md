# ERP Build and Connected Services — Overview

- Web app and static site
- Payments (e.g., Stripe)
- Open Banking (e.g., TrueLayer)
- HMRC VAT (MTD)
- Analytics (only with consent)
