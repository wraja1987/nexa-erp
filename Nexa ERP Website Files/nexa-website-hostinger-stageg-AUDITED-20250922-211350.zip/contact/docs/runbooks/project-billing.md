# project billing — Runbook

## Goal
Clear steps to complete the project billing process.

## Steps
1) Start
2) Enter details
3) Review
4) Approve
5) Complete
