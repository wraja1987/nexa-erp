# deploy — Runbook

## Purpose
Simple, reliable steps to perform deploy.

## Steps
- Follow the checklist.
