# rollback — Runbook

## Purpose
Simple, reliable steps to perform rollback.

## Steps
- Follow the checklist.
