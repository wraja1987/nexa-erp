# incident severity — Runbook

## Purpose
Simple, reliable steps to perform incident severity.

## Steps
- Follow the checklist.
