# comms templates — Runbook

## Purpose
Simple, reliable steps to perform comms templates.

## Steps
- Follow the checklist.
