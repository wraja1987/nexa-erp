# Asset Inventory
List systems, apps, domains, servers, databases, storage, third parties.
