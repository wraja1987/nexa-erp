# Data Classification Register
Define Public, Internal, Confidential with handling rules.
