# Nexa ERP — Backend Deploy Notes

## Quick Start (Docker)
1) Copy `.env.example` to `.env` and fill real values.
2) Run Prisma migrations:
   ```
   ./prisma-migrate.sh ./ .env
   ```
3) Start:
   ```
   docker compose -f docker/docker-compose.yml up -d
   ```
4) Health:
   ```
   ./health-check.sh https://api.nexaai.co.uk
   ```

## Quick Start (PM2)
1) Build once locally or on the server (standalone already included).
2) Copy `.env.example` to `.env` and fill real values.
3) Install pm2 and start:
   ```
   npm i -g pm2
   pm2 start pm2/ecosystem.config.cjs --env production
   pm2 save
   ```

## Hostinger VPS tips
- Point A records for `app.nexaai.co.uk` and `api.nexaai.co.uk` to the VPS.
- If using Caddy, it will request TLS certs automatically.
- Ensure DB/Redis credentials are secure; do not expose ports publicly.

