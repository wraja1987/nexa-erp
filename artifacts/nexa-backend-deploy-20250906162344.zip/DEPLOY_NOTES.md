# Nexa ERP — Backend Deploy Notes

## Quick Start (Docker)
1) Copy  to  and fill real values.
2) Run Prisma migrations:
   
3) Start:
   
4) Health:
   

## Quick Start (PM2)
1) Build once locally or on the server (standalone already included).
2) Copy  to  and fill real values.
3) Install pm2 and start:
   

## Hostinger VPS tips
- Point A records for  and  to the VPS.
- If using Caddy, it will request TLS certs automatically.
- Ensure DB/Redis credentials are secure; do not expose ports publicly.

